﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//To work with xml data namespace
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack) //Tells the compiler not to 
            //do any work on below code for postback or reload
        {
            //Initially the button should be inactive
            btnRegister.Enabled = false;

            //When you add data to dropdown add under !PostBack
            //section
            //Create a List of data
            List<string> stateList = new List<string>();
            stateList.Add("Select");
            stateList.Add("Andhra Pradesh");
            stateList.Add("Karnataka");
            stateList.Add("Tamil Nadu");
            stateList.Add("West Bengal");

            //Add the data to DropDownList
            ddlStates.DataSource = stateList;
            //DataSource property tell compiler where to look for
            //data that should be bounded to the dropdown control
            ddlStates.DataBind();
            //DataBind property is used to bind the data
            //under dropdown collected from datasource
        }
    }

    //The checkbox is checked event determinesd
    //whether button is to be activated or not
    protected void chkAgreement_CheckedChanged(object sender, EventArgs e)
    {
        if(chkAgreement.Checked==true)
            //ie user clicks on checkbox
        {
            btnRegister.Enabled = true;
        }
        else
        {
            btnRegister.Enabled = false;
        }

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        try
        {
            //Add data to xml file
            //(i) Create an XMLDocument Object
            XmlDocument doc = new XmlDocument();
            //(ii)Load the xml file that you have just created
            doc.Load(Server.MapPath("Customers.xml"));
            //(iii) select the root node from xml under which you create child nodes
            XmlNode rootnode = doc.SelectSingleNode("CustomerDetail");
            //(iv) Create Child nodes called Customer
            XmlNode childNode = rootnode.AppendChild(doc.CreateNode
                (XmlNodeType.Element, "Customer", ""));
            //(v) Add elements like username,password etc to child node
            childNode.AppendChild(doc.CreateNode
           (XmlNodeType.Element, "username", "")).InnerText = txtUsername.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "password", "")).InnerText = txtPassword.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "email", "")).InnerText = txtEmail.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "phone", "")).InnerText = txtPhone.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "address", "")).InnerText = txtAddress.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "gender", "")).InnerText = lblGenderSelected.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "dob", "")).InnerText = txtDob.Text;
            childNode.AppendChild(doc.CreateNode
          (XmlNodeType.Element, "states", "")).InnerText = ddlStates.SelectedItem.Text;
            //(vi) Write the data back to xml file
            doc.Save(Server.MapPath("Customers.xml"));
            Response.Write("<script>alert('Customer Registered Successfully');" +
                "window.location.href='Home.aspx'</script>");

        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message);
        }

    }

    protected void ddlStates_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Select the item under DropDown and display under Label
        displayLabel.Text = "Your Selected State: " +
            ddlStates.SelectedItem.Text;
        //The SelectedItem.Text will collect the value of
        //data selected from dropdown

    }

    protected void radioMale_CheckedChanged(object sender, EventArgs e)
    {
        if(radioMale.Checked==true) //ie user has clicked the male radio
        {
            radioFemale.Checked = false;
            lblGenderSelected.Text = radioMale.Text;
        }
    }

    protected void radioFemale_CheckedChanged(object sender, EventArgs e)
    {
        if(radioFemale.Checked==true) //ie user has clicked the female radio
        {
            radioMale.Checked = false;
            lblGenderSelected.Text = radioFemale.Text;
        }
    }
}