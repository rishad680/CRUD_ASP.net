﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//Use namespace to call xml data
using System.Xml;
//to use dataset
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Call the Username name under !PostBack to retain the data
        if(!Page.IsPostBack)
        {
            Label2.Text = Session["username"].ToString();
            //call the displayData() under Postback of page Load
            displayData();
        }
    }

    protected void displayData()
    {
        //This function will contain code to display data in GridView
        /*(i) Take a DataSet which is a local container to hold xml records
         * or SQL Tables to do operations locally [namespace: System.Data] */
        DataSet ds = new DataSet();
        //use ReadXml() method to read data from xml file and
        //store it on local dataset
        ds.ReadXml(Server.MapPath("Customers.xml"));
        //Tell the compiler what is the data container from where
        //GridView will collect the data
        gridCustomer.DataSource = ds;
        //Bind the data of dataset to GridView
        gridCustomer.DataBind();

    }

    protected void EditRecord_gridCustomer(object sender, GridViewEditEventArgs e)
    {
        //Open textboxes in gridview for editing data
        //Find the record that you want to edit and opens textboxes for that row
        gridCustomer.EditIndex = e.NewEditIndex;
        //GridView.EditIndex propert will search for the row which needs the
        //textboxes for edition purpose
        displayData();
    }
    protected void CancelEdit_gridCustomer(object sender, GridViewCancelEditEventArgs e)
    {
        //cancel Edit and display a normal gridview
        gridCustomer.EditIndex = -1;
        //-1 in EditIndex will restore Grid from edit view to normal display view
        displayData();
    }


    protected void UpdateRecord_gridCustomer(object sender, GridViewUpdateEventArgs e)
    {
        //update data present under textboxes in gridview 
        //(i) Create a row under which you want to keep all your recoerds for
        //update work
        GridViewRow row = (GridViewRow)gridCustomer.Rows[e.RowIndex];
        //Create a Row with the row information from gridCustomer that you want
        //to update

        //To reach the row navigate through data rows in GridView and tell
        //compiler which row is getting updated from GridView
        int row_count = gridCustomer.Rows[e.RowIndex].DataItemIndex;

        //Create textboxes to store grid info for update (or name Grid Textboxes)
        TextBox usernameTextBox = (TextBox)row.Cells[0].Controls[0];        
        //So under row which you want to update the first column will have
        //cell no=0 and a single control[control=0]
        TextBox passwordTextBox = (TextBox)row.Cells[1].Controls[0];
        TextBox emailTextBox = (TextBox)row.Cells[2].Controls[0];
        TextBox phoneTextBox = (TextBox)row.Cells[3].Controls[0];
        TextBox addressTextBox = (TextBox)row.Cells[4].Controls[0];
        TextBox genderTextBox = (TextBox)row.Cells[5].Controls[0];
        TextBox dobTextBox = (TextBox)row.Cells[6].Controls[0];
        TextBox statesTextBox = (TextBox)row.Cells[7].Controls[0];

        //Also provide facility to move the Grid to Display mode once update
        //done or cancel is done
        gridCustomer.EditIndex = -1;
        displayData();

        //Update data in xml file that you will update from Grid
        //Create a local storage dataset which collects data from Grid to update
        DataSet ds = gridCustomer.DataSource as DataSet;
        //The DataSet will contain a table structure; this table will contain
        //grid data so go to the row whose data you want to update and
        //select the column ie xml element name
        ds.Tables[0].Rows[row_count]["username"] = usernameTextBox.Text;
        ds.Tables[0].Rows[row_count]["password"] = passwordTextBox.Text;
        ds.Tables[0].Rows[row_count]["email"] = emailTextBox.Text;
        ds.Tables[0].Rows[row_count]["phone"] = phoneTextBox.Text;
        ds.Tables[0].Rows[row_count]["address"] = addressTextBox.Text;
        ds.Tables[0].Rows[row_count]["gender"] = genderTextBox.Text;
        ds.Tables[0].Rows[row_count]["dob"] = dobTextBox.Text;
        ds.Tables[0].Rows[row_count]["states"] = statesTextBox.Text;

        //Write updated data back to xml file
        ds.WriteXml(Server.MapPath("Customers.xml"));
        Response.Write("Customer with username= " + usernameTextBox.Text +
            " is updated successfully");
        displayData();
    }

   
    protected void DeleteRecord_gridCustomer(object sender, GridViewDeleteEventArgs e)
    {
        displayData();
        //Delete record from xml or sql 
        //store GridData in local DataSet
        DataSet ds = gridCustomer.DataSource as DataSet;
        //Find and delete data by its row number
        ds.Tables[0].Rows[gridCustomer.Rows[e.RowIndex].DataItemIndex].Delete();
        //Write the delete in xml      
        ds.WriteXml(Server.MapPath("Customers.xml"));
        Response.Write("<script>alert('Data Deleted')</script>");
        displayData();
    }
}