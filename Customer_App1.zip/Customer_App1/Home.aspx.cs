﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCustomer_Click(object sender, EventArgs e)
    {
        string dateInfo = Hiddenvalue();
        //step1: Create the query string variable and pass under url
        Response.Redirect("CustomerLogin.aspx?date="+dateInfo);
    }

    protected void btnAdmin_Click(object sender, EventArgs e)
    {
       
        Response.Redirect("AdminLogin.aspx");
    }
    protected string Hiddenvalue()
    {
        HiddenField1.Value = System.DateTime.Now.ToString();
        return HiddenField1.Value;
    }
}